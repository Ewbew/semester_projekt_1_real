/*
 * Motor.h
 *
 * Created: 6/14/2024 3:48:41 PM
 *  Author: ottosejrskildsantess
 */ 


class Motor{
	private:
		int speed_;
	// B�r motoren have previous_speed_, s� at den gradvist kan komme op p� nuv�rende speed?
	public:
	};